/*

*	Assignment Part B
*	The purpose is to implement the CoinSorterGUI class for Assignment.

*	*/

public class TestCoinSorterGUI extends CoinSorterGUI{

	public static void main(String[] args) 
	{
		launch(args);
	}

}
